import img1 from './images/html.jpg';
import img2 from './images/js.jpg';
import img3 from './images/game.jpg';
import img4 from './images/node.jpg';
import img5 from './images/mobile.jpg';
import img6 from './images/nursing.jpg';
const data = {
    cardData:[
        {
            id:1,
            img:img1,
            title:'HTML Tutorial',
            desp:'HTML Tutorial dolor  sit amet consectetur adipisicing elit. Laboriosam amet tenetur, nulla nisi animi nostrum iusto.'
        },
        {
            id:2,
            img:img2,
            title:'JavaScript Tutorial',
            desp:'JavaScript Tutorial dolor sit amet consectetur adipisicing elit. Laboriosam amet tenetur, nulla nisi animi nostrum iusto.'
        },
        {
            id:3,
            img:img3,
            title:'Gaming Tutorial',
            desp:'Gaming Tutorial dolor sit amet consectetur adipisicing elit. Laboriosam amet tenetur, nulla nisi animi nostrum iusto.'
        },
        {
            id:4,
            img:img4,
            title:'Node Tutorial',
            desp:'Node Tutorial dolor sit amet consectetur adipisicing elit. Laboriosam amet tenetur, nulla nisi animi nostrum iusto.'
        },
        {
            id:4,
            img:img5,
            title:'Mobile App Tutorial',
            desp:'Mobile App Tutorial dolor sit amet consectetur adipisicing elit. Laboriosam amet tenetur, nulla nisi animi nostrum iusto.'
        },
        {
            id:4,
            img:img6,
            title:'Nursing Tutorial',
            desp:'Nusing Tutorial dolor sit amet consectetur adipisicing elit. Laboriosam amet tenetur, nulla nisi animi nostrum iusto.'
        }
    ]
}
export default data;